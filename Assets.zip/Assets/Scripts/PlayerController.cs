using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using UnityEngine.XR;
using System.Collections.Generic;

public class PlayerController : MonoBehaviour
{
    public float speed = 50.0f;
    private Rigidbody rb;
    private int count;

    public Transform cameraTransform;

    public TextMeshProUGUI countText;
    public TextMeshProUGUI winText;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        count = 0;
        SetCountText();
        winText.gameObject.SetActive(false);
    }

    void FixedUpdate()
    {

        Vector3 movementDirection = cameraTransform.forward;

        movementDirection.y = 0f;

        movementDirection.Normalize();

        Vector3 movement = movementDirection * speed;


        rb.velocity = new Vector3(movement.x, rb.velocity.y, movement.z);
    }

    private void OnTriggerEnter(Collider other)
    {

        if (other.gameObject.CompareTag("PickUp"))
        {
            other.gameObject.SetActive(false);
            count += 1;
            SetCountText();
        }
    }

    void SetCountText()
    {

        countText.text = "Count: " + count.ToString();


        if (count >= 13)
        {
            winText.gameObject.SetActive(true);
        }
    }

    public void Reload()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
