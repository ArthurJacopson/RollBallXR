using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveObject : MonoBehaviour
{

    void Start()
    {
        
    }
    public Rigidbody rb;
    public float forceAmount = 10;
    void Update()
    {
        rb.AddForce(Vector3.up * forceAmount);
    }
}
